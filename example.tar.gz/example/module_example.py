# This is an example of module
import numpy as np
import matplotlib.pyplot as plt



def print_hello_word():
    print("Hello world!")
    

def plt_example():
    xsize = 16
    ysize = 12
    x = np.linspace(-5, 5, 101)
    y = [0.0]*101
    y = [1./(elem**2+1.) for elem in x]
    
    plt.figure(num='fig1',figsize=(xsize,ysize))
    plt.plot(x, y,'bo-')
    plt.title('example')
    plt.show()