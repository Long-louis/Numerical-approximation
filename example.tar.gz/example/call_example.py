# -*- coding: utf-8 -*-
"""
Created on Tue Oct 13 14:23:15 2020

@author: hp
"""

import module_example

def main():
    module_example.print_hello_word()
    module_example.plt_example()
main()
    