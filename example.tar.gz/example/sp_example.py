from scipy.sparse import csc_matrix
from scipy.sparse.linalg import spsolve
import numpy as np

def sp_example(n):
    
    nz = 3*n-4
    I = [0]*nz
    J = [0]*nz
    s = [0.0]*nz
    
    # construct sparse matrix
    # first line of matrix (line 0)
    I[0] = 0
    J[0] = 0
    s[0] = 1.
    #  line 1:n-2
    for i in range(1,n-1):
        I[3*(i-1)+1] = i
        J[3*(i-1)+1] = i-1
        s[3*(i-1)+1] = 1
        I[3*(i)-1] = i
        J[3*(i)-1] = i
        s[3*(i)-1] = 4
        I[3*(i)] = i
        J[3*(i)] = i+1
        s[3*(i)] = 1
    # last line (line n-1)
    I[nz-1] = n-1
    J[nz-1] = n-1
    s[nz-1] = 1.

    sa = csc_matrix((s, (I, J)), shape=(n, n))
    

    # construct the second member
    b = [0.0]*n
    Solex = [1.0]*n
    b = sa*Solex
    
    
    # solve linear system
    Sol = spsolve(sa, b)
    
    print('The error is ',np.linalg.norm(Sol-Solex, axis=None, keepdims=True))
    
    return Sol
    

sol = sp_example(1000)